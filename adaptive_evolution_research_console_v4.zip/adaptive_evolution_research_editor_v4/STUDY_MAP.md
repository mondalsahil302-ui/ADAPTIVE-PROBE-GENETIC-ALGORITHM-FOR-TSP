# Notebook → Dashboard Study Map

The dashboard maps the supplied notebook into inspectable modules.

| Notebook block | Research module |
|---|---|
| 3–4 | TSPLIB parsing, KNN, route utilities, fitness, gap |
| 5–8 | Nearest Neighbor, Greedy Edge, Random Tour, 2-Opt, Or-Opt, Selective LKH |
| 9–10 | Initial 70-individual population, Predictive Memory Graph |
| 11–12 | Tournament Selection, OX/Segment Crossover, Swap Mutation, Weak-Edge Surgery, Adaptive Operator Selector |
| 13 | Diversity, Stagnation Detector, Double-Bridge Escape |
| 14 | Main Adaptive GA: generation loop, global-best history, gap/stopping conditions |
| 20–21 | Convergence graph and final optimized route |

The research dashboard stores every generation and its complete population separately from the global-best trajectory, allowing generation replay and best-generation-centric analysis.
