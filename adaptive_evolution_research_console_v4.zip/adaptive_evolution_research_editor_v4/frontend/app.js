const $=id=>document.getElementById(id);
let S=null, selectedGen=0, selectedDetail=null, pollTimer=null, elapsedTimer=null, autoFollow=true, knownGenerationSet=new Set();

async function api(url,opt={}){const r=await fetch(url,opt);const d=await r.json();if(!r.ok)throw Error(d.detail||d.message||"Request failed");return d}
const fmt=(x,d=2)=>x==null?"—":Number(x).toLocaleString(undefined,{maximumFractionDigits:d});
const esc=x=>String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const sec=s=>{if(s==null)return"—";s=Math.max(0,Math.floor(s));let h=Math.floor(s/3600),m=Math.floor((s%3600)/60),q=s%60;return h?`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(q).padStart(2,"0")}`:`${String(m).padStart(2,"0")}:${String(q).padStart(2,"0")}`};
function elapsed(){if(!S?.run?.started)return 0;return (S.run.finished??Date.now()/1000)-S.run.started}

function render(s){
 S=s;
 const d=s.dataset,st=s.status;
 $("meta").innerHTML=`<b>${esc(d.name)}</b><br>${d.cities} cities · ${esc(d.weight_type)}<br>Known best: ${d.best_known==null?"unknown":fmt(d.best_known)}`;
 $("mCost").textContent=fmt(st.best_cost);$("mGap").textContent=st.gap==null?"unknown":`${fmt(st.gap,4)}%`;
 $("mGen").textContent=st.generation;$("mBest").textContent=st.best_generation;$("mDiv").textContent=s.latest?.diversity==null?"—":fmt(s.latest.diversity,4);$("mElapsed").textContent=sec(elapsed());
 $("popInfo").textContent=`${st.population_size} / generation`;$("maxInfo").textContent=s.config.max_generations;$("kInfo").textContent=s.config.k_neighbors;$("mutInfo").textContent=s.config.mutation_rate;$("lkhInfo").textContent=`every ${s.config.lkh_cadence}`;
 $("liveTitle").textContent=s.run.active?`Running · generation ${st.generation+1} preparing`:(st.converged?"Experiment converged":st.stop_reason);
 $("liveMeta").textContent=s.run.active?`Generation ${st.generation} is committed. The next generation is running in the background.`:`${s.generations_available.length} generation record(s) available for inspection.`;
 const pct=Math.min(100,100*st.generation/Math.max(1,s.config.max_generations));$("progressFill").style.width=`${pct}%`;$("progressText").textContent=`${st.generation} / ${s.config.max_generations}`;
 $("runBtn").disabled=s.run.active;$("stopBtn").disabled=!s.run.active;
 updateGenerationPicker();renderFeed();renderTables();renderCharts();renderInitial();renderOperators();
 $("console").textContent=`LIVE RESEARCH CONSOLE
Dataset             : ${d.name}
Cities              : ${d.cities}
Completed generation: ${st.generation}
Population / gen    : ${st.population_size}
Global best cost    : ${fmt(st.best_cost)}
Optimality gap      : ${st.gap==null?"unknown":fmt(st.gap,4)+"%"}
Best generation     : ${st.best_generation}
Elapsed run time    : ${sec(elapsed())}
Status              : ${s.run.active?"RUNNING":"IDLE / FINISHED"}
${s.run.error?`ERROR: ${s.run.error}`:""}
`;
 if(s.run.active){startPolling()}else stopPolling();
 if(selectedDetail==null || Number(selectedDetail.generation)!==selectedGen) loadGeneration(selectedGen);
}

function updateGenerationPicker(){
 const gens=S.generations_available||[0];
 if(!gens.includes(selectedGen)) selectedGen=gens[gens.length-1]??0;
 $("genSelect").innerHTML=gens.map(g=>`<option value="${g}">Generation ${g}</option>`).join("");
 $("genSelect").value=String(selectedGen);
}
function renderFeed(){
 const gens=S.generations_available||[];
 $("generationFeed").innerHTML=gens.map(g=>{
   const r=S.records.find(x=>x.generation===g)||{};
   return `<div class="feed-item ${g===selectedGen?"active":""}" data-gen="${g}">
     <b>GEN ${g}</b><span>${fmt(r.best_cost)}</span><em>${fmt(r.execution_time,4)} s</em>
   </div>`;
 }).join("");
 document.querySelectorAll(".feed-item").forEach(x=>x.onclick=()=>selectGeneration(Number(x.dataset.gen),false));
}
function selectGeneration(g,follow=true){
 selectedGen=g;autoFollow=follow;selectedDetail=null;updateGenerationPicker();renderFeed();loadGeneration(g);
}
async function loadGeneration(g){
 if(!S?.generations_available?.includes(g))return;
 try{
   selectedDetail=await api(`/api/generation/${g}`);
   renderGenerationDetail();
 }catch(e){$("console").textContent+=`\nGeneration ${g} load error: ${e.message}`}
}
function renderGenerationDetail(){
 const d=selectedDetail,r=d.record||{},pop=d.population||[];
 $("routeInfo").innerHTML=`<span><b>Generation</b> ${d.generation}</span><span><b>Population</b> ${d.population_count}</span><span><b>Best</b> ${fmt(r.best_cost)}</span><span><b>Gap</b> ${r.gap==null?"unknown":fmt(r.gap,4)+"%"}</span><span><b>Improvement</b> ${fmt(r.improvement)}</span><span><b>Time</b> ${fmt(r.execution_time,4)} s</span>`;
 $("genSummary").innerHTML=[
 ["Population",d.population_count],["Best cost",fmt(r.best_cost)],["Gap",r.gap==null?"unknown":fmt(r.gap,4)+"%"],["Operator",r.operator||"Initialization"],
 ["Diversity",r.diversity==null?"—":fmt(r.diversity,4)],["PMG trust",fmt(r.memory_trust,3)],["LKH",r.lkh_applied?"Applied":"Not scheduled"],["Double-Bridge",r.double_bridge_applied?"Applied":"Not applied"],
 ["Best ID",r.best_id??"—"],["New global best",r.new_global_best?"Yes":"No"],["Generation time",fmt(r.execution_time,4)+" s"],["No-improvement",r.no_improvement_count??"—"]
 ].map(x=>`<div class="sum"><span>${x[0]}</span><b>${esc(x[1])}</b></div>`).join("");
 $("selectedRoute").textContent=(d.route||[]).join(" → ");
 renderRoute(d.route||[]);
 $("populationTable").innerHTML=pop.map((x,i)=>`<tr><td>${i+1}</td><td>${x.id}</td><td>${fmt(x.cost)}</td><td>${fmt(x.fitness,10)}</td><td>${esc(x.method)}</td><td class="route-cell">${esc((x.tour||[]).join(" → "))}</td></tr>`).join("");
 $("popCaption").textContent=`Generation ${d.generation} · ${d.population_count} population member(s)`;
}
function renderRoute(route){
 const byCity=new Map((S.route||[]).map(p=>[p.city,p]));const pts=route.map(c=>byCity.get(c)).filter(Boolean);
 if(pts.length<2){$("routeViz").innerHTML="";return}
 const W=920,H=385,P=42,xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),minx=Math.min(...xs),maxx=Math.max(...xs),miny=Math.min(...ys),maxy=Math.max(...ys);
 const sc=Math.min((W-2*P)/Math.max(1e-9,maxx-minx),(H-2*P)/Math.max(1e-9,maxy-miny)),X=x=>P+(x-minx)*sc+(W-2*P-(maxx-minx)*sc)/2,Y=y=>H-P-(y-miny)*sc-(H-2*P-(maxy-miny)*sc)/2;
 const closed=[...pts,pts[0]];let svg=`<svg viewBox="0 0 ${W} ${H}"><text x="18" y="21" class="axis">Best route · Generation ${selectedGen}</text><polyline points="${closed.map(p=>`${X(p.x)},${Y(p.y)}`).join(" ")}" fill="none" stroke="#2563eb" stroke-width="2.4"/>`;
 pts.forEach((p,i)=>svg+=`<circle cx="${X(p.x)}" cy="${Y(p.y)}" r="${i===0?5:3}" fill="${i===0?"#f97316":"#2563eb"}"/><text x="${X(p.x)+5}" y="${Y(p.y)-5}" font-size="8" fill="var(--muted)">${p.city}</text>`);
 $("routeViz").innerHTML=svg+"</svg>";
}
function makeChart(id,series,opts){
 const el=$(id);if(!series?.[0]?.values?.length){el.innerHTML="";return}
 const W=900,H=290,L=66,R=18,T=24,B=52,iw=W-L-R,ih=H-T-B,all=series.flatMap(s=>s.values).filter(Number.isFinite);let lo=opts.zero?0:Math.min(...all),hi=Math.max(...all);if(Math.abs(hi-lo)<1e-12){hi+=1;lo=Math.max(0,lo-1)}
 const n=Math.max(...series.map(s=>s.values.length)),X=i=>L+i*iw/Math.max(1,n-1),Y=v=>T+(hi-v)*ih/(hi-lo);
 let out=`<svg viewBox="0 0 ${W} ${H}">`;
 for(let j=0;j<=5;j++){const v=lo+(hi-lo)*j/5,y=Y(v);out+=`<line x1="${L}" y1="${y}" x2="${W-R}" y2="${y}" class="gridline"/><text x="${L-9}" y="${y+4}" text-anchor="end" class="axis">${fmt(v,opts.yDigits??2)}</text>`}
 const ticks=Math.min(10,n);for(let j=0;j<ticks;j++){const i=Math.round(j*(n-1)/Math.max(1,ticks-1)),x=X(i);out+=`<line x1="${x}" y1="${T}" x2="${x}" y2="${H-B}" class="gridline" opacity=".45"/><text x="${x}" y="${H-B+17}" text-anchor="middle" class="axis">${i}</text>`}
 out+=`<line x1="${L}" y1="${H-B}" x2="${W-R}" y2="${H-B}" stroke="var(--text)"/><line x1="${L}" y1="${T}" x2="${L}" y2="${H-B}" stroke="var(--text)"/><text x="${L+iw/2}" y="${H-11}" text-anchor="middle" class="axis-title">${esc(opts.xLabel)}</text><text x="14" y="${T+ih/2}" transform="rotate(-90 14 ${T+ih/2})" text-anchor="middle" class="axis-title">${esc(opts.yLabel)}</text>`;
 series.forEach((s,si)=>{const pts=s.values.map((v,i)=>`${X(i)},${Y(v)}`).join(" ");out+=`<polyline points="${pts}" class="${si===0?"blue-line":"orange-line"}"/>`;if(opts.points) s.values.forEach((v,i)=>out+=`<circle cx="${X(i)}" cy="${Y(v)}" r="3" class="blue-point"><title>${esc(s.name)} · Generation ${i} · ${fmt(v,opts.yDigits??2)}</title></circle>`)});
 if(series.length>1)out+=`<rect x="${W-205}" y="13" width="11" height="4" fill="#2563eb"/><text x="${W-188}" y="18" class="axis">${esc(series[0].name)}</text><rect x="${W-102}" y="13" width="11" height="4" fill="#f97316"/><text x="${W-85}" y="18" class="axis">${esc(series[1].name)}</text>`;
 el.innerHTML=out+"</svg>";
}
function renderCharts(){
 makeChart("convergence",[{name:"Global best cost",values:S.history}],{xLabel:"Generation",yLabel:"Tour cost",yDigits:0,points:true});
 makeChart("improvement",[{name:"Cost reduction",values:S.records.map(r=>Number(r.improvement||0))}],{xLabel:"Generation",yLabel:"Improvement in cost",yDigits:2,zero:true,points:true});
 makeChart("timeChart",[{name:"Generation time",values:S.records.map(r=>Number(r.execution_time||0))}],{xLabel:"Generation",yLabel:"Execution time (seconds)",yDigits:4,zero:true,points:true});
 makeChart("diversityChart",[{name:"Diversity",values:S.records.map(r=>Number(r.diversity||0))},{name:"PMG trust",values:S.records.map(r=>Number(r.memory_trust||0))}],{xLabel:"Generation",yLabel:"Diversity / trust",yDigits:3,zero:true});
}
function renderTables(){
 $("generationTable").innerHTML=S.records.map(r=>`<tr data-gen="${r.generation}"><td>${r.generation}</td><td>${S.population_counts?.[r.generation]??S.status.population_size}</td><td>${fmt(r.best_cost)}</td><td>${r.gap==null?"—":fmt(r.gap,4)+"%"}</td><td>${fmt(r.improvement)}</td><td>${esc(r.operator||"Initialization")}</td><td>${fmt(r.execution_time,4)}</td></tr>`).join("");
 document.querySelectorAll("#generationTable tr").forEach(tr=>tr.onclick=()=>selectGeneration(Number(tr.dataset.gen),false));
}
function renderInitial(){
 const a=S.initial;
 $("initialOutputs").innerHTML=[
 ["Greedy seed",a.greedy_cost,a.greedy_time],["2-Opt local",a.two_opt_local_cost,a.two_opt_local_time],["2-Opt refinement",a.two_opt_refined_cost,a.two_opt_refined_time],["Initial population best",Math.min(...((S.generations_available.includes(0)?[]:[])),a.two_opt_refined_cost),a.population_time]
 ].map(x=>`<div class="initial"><b>${x[0]}</b><div class="cost">${fmt(x[1])}</div><small>${fmt(x[2],4)} s</small></div>`).join("");
}
function renderOperators(){
 const plays=S.operator_activity?.plays||{},credit=S.operator_activity?.credit||{};
 const keys=[...new Set([...Object.keys(plays),...Object.keys(credit)])];
 $("operatorActivity").innerHTML=keys.map(k=>`<div class="op"><span>${esc(k.replaceAll("_"," "))}</span><b>${plays[k]||0} · ${fmt(credit[k]||0)}</b></div>`).join("")||"<div class='caption'>No generation activity yet.</div>";
}
function startPolling(){if(pollTimer)return;pollTimer=setInterval(async()=>{try{const s=await api("/api/live");const oldLatest=S?.status?.generation??0;const wasLatest=autoFollow && selectedGen===oldLatest;render(s);if(s.status.generation>oldLatest && wasLatest){selectedGen=s.status.generation;selectedDetail=null;updateGenerationPicker();renderFeed();loadGeneration(selectedGen)}}catch(e){}},650)}
function stopPolling(){if(pollTimer){clearInterval(pollTimer);pollTimer=null}}
function startElapsedTimer(){if(elapsedTimer)return;elapsedTimer=setInterval(()=>{$("mElapsed").textContent=sec(elapsed())},500)}

$("genSelect").onchange=e=>selectGeneration(Number(e.target.value),false);
$("prevGen").onclick=()=>{const g=S.generations_available||[],i=g.indexOf(selectedGen);if(i>0)selectGeneration(g[i-1],false)};
$("nextGen").onclick=()=>{const g=S.generations_available||[],i=g.indexOf(selectedGen);if(i>=0&&i<g.length-1)selectGeneration(g[i+1],false)};
$("jumpLatest").onclick=()=>{const g=S.generations_available||[];if(g.length)selectGeneration(g[g.length-1],true)};
$("runBtn").onclick=async()=>{try{const r=await api("/api/run-all/start",{method:"POST"});render(r);startPolling()}catch(e){$("console").textContent=e.message}};
$("stopBtn").onclick=async()=>{try{render(await api("/api/run-all/stop",{method:"POST"}))}catch(e){$("console").textContent=e.message}};
$("resetBtn").onclick=async()=>{try{stopPolling();const s=await api("/api/reset",{method:"POST"});selectedGen=0;selectedDetail=null;autoFollow=true;render(s)}catch(e){$("console").textContent=e.message}};
$("themeBtn").onclick=()=>{document.body.classList.toggle("dark");$("themeBtn").textContent=document.body.classList.contains("dark")?"Light mode":"Dark mode";localStorage.setItem("ae-theme",document.body.classList.contains("dark")?"dark":"light")};
if(localStorage.getItem("ae-theme")==="dark"){document.body.classList.add("dark");$("themeBtn").textContent="Light mode"}
const dz=$("dropZone"),fi=$("fileInput");dz.onclick=()=>fi.click();fi.onchange=()=>fi.files[0]&&upload(fi.files[0]);dz.ondragover=e=>e.preventDefault();dz.ondrop=e=>{e.preventDefault();if(e.dataTransfer.files[0])upload(e.dataTransfer.files[0])};
async function upload(file){try{const fd=new FormData();fd.append("file",file);const s=await api("/api/upload",{method:"POST",body:fd});selectedGen=0;selectedDetail=null;autoFollow=true;render(s);startElapsedTimer();await loadGeneration(0)}catch(e){$("console").textContent=`UPLOAD ERROR\n${e.message}`}}
async function init(){startElapsedTimer();try{const s=await api("/api/state");render(s)}catch(e){}}
init();
