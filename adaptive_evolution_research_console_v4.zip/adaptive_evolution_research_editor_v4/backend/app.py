from __future__ import annotations

import io, tempfile, time, threading, traceback
from pathlib import Path
from typing import Any
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .algorithm_core import *

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"

app = FastAPI(title="Adaptive Evolution Research Editor", version="3.0")
app.mount("/frontend", StaticFiles(directory=FRONTEND), name="frontend")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

STATE: dict[str, Any] = {"st": None, "filename": None}
RUN: dict[str, Any] = {"active": False, "started": None, "finished": None, "error": None, "mode": None}
LOCK = threading.RLock()

class RunConfig(BaseModel):
    values: dict[str, Any] = {}

def load_csv(data, name):
    import pandas as pd
    df = pd.read_csv(io.BytesIO(data))
    cols = {str(c).strip().lower(): c for c in df.columns}
    x = cols.get("x") or cols.get("longitude") or cols.get("lon")
    y = cols.get("y") or cols.get("latitude") or cols.get("lat")
    if x is None or y is None:
        nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        if len(nums) < 2:
            raise ValueError("CSV needs x/y or two numeric columns")
        x, y = nums[:2]
    coords = df[[x, y]].astype(float).to_numpy()
    n = len(coords)
    if n < 3:
        raise ValueError("Need at least 3 cities")
    d = coords[:, None, :] - coords[None, :, :]
    dist = np.sqrt((d ** 2).sum(axis=2))
    return TSPInstance(Path(name).stem, n, list(range(n)), dist, coords, "EUCLIDEAN_CSV")

def get_state():
    with LOCK:
        if STATE["st"] is None:
            raise HTTPException(400, "Upload a dataset first")
        return STATE["st"]

def coords_for(inst):
    if inst.coords is not None:
        return inst.coords
    d = inst.dist
    n = inst.n
    J = np.eye(n) - np.ones((n, n)) / n
    B = -.5 * J @ (d ** 2) @ J
    vals, vecs = np.linalg.eigh(B)
    idx = np.argsort(vals)[::-1][:2]
    vals = np.clip(vals[idx], 0, None)
    return vecs[:, idx] * np.sqrt(vals)

def payload(st):
    inst = st["instance"]
    opt = best_known(inst.name)
    c = coords_for(inst)
    route = st["global_best_tour"]
    with LOCK:
        records = list(st["records"])
        gens = sorted(st["populations"].keys())
        latest = records[-1] if records else None
        return {
            "dataset": {
                "name": inst.name, "cities": inst.n, "weight_type": inst.edge_weight_type,
                "best_known": opt, "has_coordinates": inst.coords is not None,
                "filename": STATE["filename"]
            },
            "config": vars(st["config"]),
            "status": {
                "generation": st["generation"],
                "best_cost": float(st["global_best_cost"]),
                "gap": gap_percent(st["global_best_cost"], opt),
                "best_generation": st["best_generation"],
                "no_improvement": st["no_improvement"],
                "converged": st["converged"],
                "stop_reason": st["stop_reason"],
                "population_size": st["config"].population_size,
            },
            "run": {
                "active": RUN["active"], "mode": RUN["mode"],
                "started": RUN["started"], "finished": RUN["finished"], "error": RUN["error"]
            },
            "initial": {
                "greedy_route": st["pipe"]["greedy"],
                "greedy_cost": float(st["pipe"]["greedy_cost"]),
                "greedy_time": float(st["pipe"]["greedy_time"]),
                "two_opt_local_route": st["pipe"]["two_opt_local"],
                "two_opt_local_cost": float(st["pipe"]["two_opt_local_cost"]),
                "two_opt_local_improved": st["pipe"]["two_opt_local_improved"],
                "two_opt_local_time": float(st["pipe"]["two_opt_local_time"]),
                "two_opt_refined_route": st["pipe"]["two_opt_refined"],
                "two_opt_refined_cost": float(st["pipe"]["two_opt_refined_cost"]),
                "two_opt_refined_improved": st["pipe"]["two_opt_refined_improved"],
                "two_opt_refined_time": float(st["pipe"]["two_opt_refined_time"]),
                "population_time": float(st["pipe"]["population_time"]),
            },
            "route": [{"city": int(city), "x": float(c[city,0]), "y": float(c[city,1])} for city in route],
            "route_text": " → ".join(map(str, route)),
            "history": [float(x) for x in st["history"]],
            "records": records,
            "improvements": list(st["improvements"]),
            "generations_available": gens,
            "population_counts": {str(g): len(st["populations"][g]) for g in gens},
            "operator_activity": {
                "plays": dict(st["selector"].plays),
                "credit": dict(st["selector"].credit)
            },
            "memory": {
                "trust": float(st["pmg"].trust),
                "top_edges": [
                    {"edge": [int(a), int(b)], "score": float(v)}
                    for (a,b),v in sorted(st["pmg"].edge_memory.items(), key=lambda z:-z[1])[:25]
                ]
            },
            "feature_totals": {k: float(v) for k,v in st["feature_totals"].items()},
            "latest": latest,
        }

def run_background():
    try:
        while True:
            with LOCK:
                st = STATE["st"]
                if st is None:
                    break
                if st["generation"] >= st["config"].max_generations or st["converged"]:
                    break
            run_generation(st)
            # Tiny yield keeps the server responsive even for very fast generations.
            time.sleep(0.001)
    except Exception as e:
        traceback.print_exc()
        with LOCK:
            RUN["error"] = str(e)
    finally:
        with LOCK:
            RUN["active"] = False
            RUN["finished"] = time.time()

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")

@app.get("/api/health")
def health():
    return {"ok": True, "elkai": HAS_ELKAI, "tsplib95": tsplib95 is not None}

@app.get("/api/state")
def state():
    return payload(get_state())

@app.get("/api/live")
def live():
    return payload(get_state())

@app.get("/api/generation/{generation}")
def generation(generation: int):
    st = get_state()
    with LOCK:
        if generation not in st["populations"]:
            raise HTTPException(404, "Generation not available yet")
        pop = st["populations"][generation]
        record = st["records"][generation]
        return {
            "generation": generation,
            "record": record,
            "population": pop,
            "population_count": len(pop),
            "route": st["route_history"][generation],
        }

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    name = file.filename or "dataset"
    try:
        if name.lower().endswith(".csv"):
            inst = load_csv(data, name)
        elif name.lower().endswith(".tsp"):
            with tempfile.NamedTemporaryFile(suffix=".tsp", delete=False) as f:
                f.write(data); p = f.name
            try:
                inst = load_any_instance(p)
            finally:
                Path(p).unlink(missing_ok=True)
        else:
            raise ValueError("Upload .tsp or .csv")
        with LOCK:
            STATE["st"] = setup_state(inst)
            STATE["filename"] = name
            RUN.update(active=False, started=None, finished=None, error=None, mode=None)
        return payload(STATE["st"])
    except Exception as e:
        raise HTTPException(400, f"Upload failed: {e}")

@app.post("/api/reset")
def reset():
    st = get_state()
    with LOCK:
        if RUN["active"]:
            raise HTTPException(409, "Stop the current run before resetting")
        STATE["st"] = setup_state(st["instance"], vars(st["config"]))
        RUN.update(active=False, started=None, finished=None, error=None, mode=None)
        return payload(STATE["st"])

@app.post("/api/research-config")
def research_config(cfg: RunConfig):
    st = get_state()
    with LOCK:
        if RUN["active"]:
            raise HTTPException(409, "Stop the current run before changing configuration")
        STATE["st"] = setup_state(st["instance"], cfg.values)
        return payload(STATE["st"])

@app.post("/api/run-generation")
def run_gen():
    st = get_state()
    with LOCK:
        if RUN["active"]:
            raise HTTPException(409, "A live experiment is already running")
        rec = run_generation(st)
        return {"record": rec, **payload(st)}

@app.post("/api/run-all/start")
def start_run_all():
    with LOCK:
        st = get_state()
        if RUN["active"]:
            return JSONResponse({"started": False, "reason": "already_running", **payload(st)}, status_code=409)
        if st["converged"] or st["generation"] >= st["config"].max_generations:
            return {"started": False, "reason": "already_finished", **payload(st)}
        RUN["active"] = True
        RUN["mode"] = "run_all"
        RUN["started"] = time.time()
        RUN["finished"] = None
        RUN["error"] = None
        thread = threading.Thread(target=run_background, daemon=True)
        thread.start()
        return {"started": True, **payload(st)}

@app.post("/api/run-all/stop")
def stop_run_all():
    # Cooperative stop: run_generation completes the current generation, then the worker exits.
    with LOCK:
        if not RUN["active"]:
            return {"stopped": False, **payload(get_state(), compact=True)}
        st = get_state()
        st["config"].max_generations = st["generation"]
        RUN["mode"] = "stopping"
        return {"stopped": True, "message": "Stopping after the current generation.", **payload(st)}

@app.post("/api/step")
def step(name: str):
    st = get_state()
    with LOCK:
        name = name.lower()
        if RUN["active"]:
            raise HTTPException(409, "A live experiment is running; inspect generations while it runs.")
        if name == "knn":
            return {"stage": "KNN", "k": st["config"].k_neighbors, "neighbors": st["neighbors"][:min(50,st["instance"].n)]}
        if name == "greedy":
            return {"stage": "Greedy Seed", "route": st["pipe"]["greedy"], "cost": st["pipe"]["greedy_cost"], "time": st["pipe"]["greedy_time"]}
        if name == "two_opt_local":
            return {"stage": "2-Opt Local", "route": st["pipe"]["two_opt_local"], "cost": st["pipe"]["two_opt_local_cost"], "time": st["pipe"]["two_opt_local_time"]}
        if name in {"two_opt_refined","refinement"}:
            return {"stage": "2-Opt Refinement", "route": st["pipe"]["two_opt_refined"], "cost": st["pipe"]["two_opt_refined_cost"], "time": st["pipe"]["two_opt_refined_time"]}
        if name == "initial_population":
            return {"stage": "Initial Population", "population": st["populations"][0]}
        if name == "memory":
            return payload(st)["memory"]
        if name == "ranking":
            return {"stage": "Generation Ranking", "population": snapshot_population(st["population"])}
        if name == "fitness_gap":
            best = min(st["population"], key=lambda x:x.cost); opt = best_known(st["instance"].name)
            return {"stage":"Fitness + Gap","best_cost":best.cost,"fitness":best.fitness,"known_best":opt,"gap":gap_percent(best.cost,opt)}
        raise HTTPException(404, "Unknown stage")
