# Adaptive Evolution Research Editor v3

A generation-first research dashboard for the supplied Adaptive Genetic Algorithm notebook.

## Main change
The algorithm's operators are fixed and always run according to the algorithm. They are displayed as a transparent pipeline rather than as selection checkboxes.

## Research workflow
1. Upload a `.tsp` TSPLIB instance or coordinate `.csv`.
2. Inspect initial Greedy → 2-Opt → refined seed outputs.
3. Press **Run Experiment**.
4. The experiment continues in a background thread.
5. The dashboard polls the backend and updates after every completed generation.
6. While the experiment is still running, select any completed generation from the Generation Route Replay control.
7. Inspect that generation's best route, full population table, metrics, convergence position, execution time and operator activity.

## Charts
All charts now have:
- explicit X-axis labels
- explicit Y-axis labels
- numeric tick marks
- gridlines
- readable units
- per-point generation tooltips for convergence/time/improvement

## Stored research records
Each completed generation stores:
- global best cost
- gap to known optimum
- improvement amount
- best individual/method
- best route
- diversity
- adaptive operator
- PMG trust
- no-improvement count
- feature-level change counts
- LKH / Double-Bridge state
- generation execution time
- complete sorted population snapshot
- complete best-route history

## Long runs
The browser never waits for the final generation to render results. The worker executes one generation, commits its record, and the frontend refreshes the study state. This supports long experiments where hundreds/thousands of generations may take significant wall-clock time.

## Start
Windows: `run_windows.bat`
macOS/Linux: `./run_mac_linux.sh`

Open `http://127.0.0.1:8000`.

Do not open `frontend/index.html` directly and do not use VS Code Live Server.

The supplied notebook's actual initial construction is Greedy → first 2-Opt → stronger 2-Opt, with Selective LKH not used during initial construction. The GA then evolves populations with selection, crossover, mutation, fast 2-Opt, PMG, adaptive refinement, diversity/stagnation, Double-Bridge and periodic LKH.


## Large-study behavior

The live dashboard does not repeatedly send every historical population snapshot.
The live endpoint sends lightweight generation summaries and convergence history.
When you select Generation N, the browser requests only that generation's stored
population and best route from `/api/generation/N`.

This keeps the browser responsive as the study grows to many generations.

The Run Experiment button starts the long run in the backend and immediately returns.
The UI polls the live state roughly every 650 ms and redraws completed generations.
